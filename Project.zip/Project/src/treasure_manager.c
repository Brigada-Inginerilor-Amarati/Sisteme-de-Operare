#include "treasure_manager.h"
#include "cmd_args_parser/cmd_args_parser.h"
#include "operations/operations.h"
#include <unistd.h>

operation_error execute_operation(int argc, char *argv[]) {
  operation op = read_operation(argc, argv);
  if (op == OPERATION_INVALID)
    return OPERATION_FAILED;

  char *hunt_id = get_hunt_id(argc, argv);
  int treasure_id = get_treasure_id(argc, argv);

  switch (op) {
  case ADD:
    return add_treasure(hunt_id, STDIN_FILENO);
  case LIST:
    if (treasure_id == -1)
      return list_hunt(hunt_id);
    else
      return list_treasure(hunt_id, treasure_id);
  case REMOVE:
    if (treasure_id == -1)
      return remove_hunt(hunt_id);
    else
      return remove_treasure(hunt_id, treasure_id);
  default:
    return NO_ERROR;
  }
}

int main(int argc, char *argv[]) {

  operation_error err = execute_operation(argc, argv);
  print_operation_error(err);

  return 0;
}
