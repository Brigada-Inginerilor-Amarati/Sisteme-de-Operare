#ifndef __OP_LIST_H
#define __OP_LIST_H

#include "../../treasure_manager.h"
operation_error list_hunt(char *path);
operation_error list_treasure(char *path, int id);
#endif
