#ifndef __OP_ADD_H
#define __OP_ADD_H

#include "../../main/treasure_manager.h"

operation_error add_treasure(char *path, int fd);
#endif
