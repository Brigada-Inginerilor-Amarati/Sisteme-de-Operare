#ifndef __OP_REMOVE_H
#define __OP_REMOVE_H

#include "../../treasure_manager.h"

operation_error remove_hunt(char *dir_name);
operation_error remove_treasure(char *path, int id);
#endif
